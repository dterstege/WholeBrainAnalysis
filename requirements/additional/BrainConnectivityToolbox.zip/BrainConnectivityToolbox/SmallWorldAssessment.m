tic;
%%
%Find L
%djt1=adjacency matrix
djt2_2=graph(djt3);
K=degree(djt2_2);
sumK=sum(K);
adjL=distance_bin(djt3);
sumDistL=mean(adjL(isfinite(adjL)));
sumDistL=mean(sumDistL);
L=((1/(height(djt2_2.Nodes)*(height(djt2_2.Nodes)-1)))*sumDistL);

%%
%Generate Lrand
nodeNum=height(djt2_2.Nodes);
CIJL=makerandCIJ_und(nodeNum,sumK);
graphCIJL=graph(CIJL);
distL=distance_bin(CIJL);
sumDistLrand=mean(distL(isfinite(distL)));
sumDistLrand=mean(sumDistLrand);
Lrand=((1/(height(graphCIJL.Nodes)*(height(graphCIJL.Nodes)-1)))*sumDistLrand);	

%%
%Find C
C=0;
%%
for i=1:height(djt2_2.Nodes)
   	if degree(djt2_2,i)>1
    ei=(length(outedges(djt2_2,i))/(height(djt2_2.Edges)));
    ki=degree(djt2_2,i);
    Ci=(2*ei)/(ki*(ki-1));
    C=C+Ci;
    else
        %do nothing
    end
end

%%
%Generate Clat
CIJC=makelatticeCIJ((nodeNum),(sumK));
graphCIJC=graph(CIJC,'upper');
Clat=0;
%%
for i=1:height(djt2_2.Nodes)
   	if degree(graphCIJC,i)>1
    ei=(length(outedges(graphCIJC,i))/(height(graphCIJC.Edges)));
    ki=degree(graphCIJC,i);
    Ci=(2*ei)/(ki*(ki-1));
    Clat=Clat+Ci;
    else
        %do nothing
    end
end
%%
%Find Omega
omega=(Lrand/L)-(C/Clat);
%%
%Generate Crand
nodeNum=height(djt2_1.Nodes);
edgeNum=height(djt2_1.Edges);
CIJC=makerandCIJ_und(nodeNum,sumK);
graphCIJC=graph(CIJC);
Crand=0;
%%
for i=1:height(djt2_1.Nodes)
   	if degree(graphCIJC,i)>1
    ei=(length(outedges(graphCIJC,i))/(height(graphCIJC.Edges)));
    ki=degree(graphCIJC,i);
    Ci=(2*ei)/(ki*(ki-1));
    Crand=Crand+Ci;
    else
        %do nothing
    end
end
%%
%Find Theta
theta=(C/Crand)/(L/Lrand);

%%
%Find C2
C2=0;
%%
for i=1:height(djt2_1.Nodes)
   	if degree(djt2_1,i)>1
    ei=(length(outedges(djt2_1,i))/(height(djt2_1.Edges)));
    ki=degree(djt2_1,i);
    Ci=(2*ei)/(ki*(ki-1));
    C2=C2+Ci;
    else
        %do nothing
    end
end

%%
%Generate Clat2
CIJC=makelatticeCIJ(nodeNum,sumK);
graphCIJC=graph(CIJC,'upper');
Clat2=0;
%%
for i=1:height(djt2_1.Nodes)
   	if degree(graphCIJC,i)>=0
    ei=(length(outedges(graphCIJC,i))/(height(graphCIJC.Edges)));
    ki=degree(graphCIJC,i);
    Ci=(3*(ki-2))/(4*(ki-1));
    Clat2=Clat2+Ci;
    else
        %do nothing
    end
end
%%
%omega2
omega2=(Lrand/L)-(C2/Clat2);
%%
txtName=strcat(xlsName,'_SmallWorldMetrics.txt');
fid=fopen(txtName,'wt');
A1={'C';'Crand';'L';'Lrand';'Omega';'Theta';'Omega2'};
A2=num2cell(vertcat(C,Crand,L,Lrand,omega,theta,omega2));
c=cat(2, A1, A2).';
formatSpec='%s : %5.4f\r\n';
fprintf(fid,formatSpec, c{:});
fclose(fid);
%%
toc